﻿
#include <iostream>

class Figura {      //Общий класс для всех фигур
public:
    int VidFigura;     //Переменная отвечает за вид фигуры(Конь, Слон, Король...)
    int Color;  //0=black 1=white 2=случайная 
    Figura() {     //Конструктор по умолчанию, используется для заполнения остатка клеток доски
        VidFigura = 0;
        Color = 2;
    }
    Figura(int v, int c) {     //Конструктор, который создает фигуры
        VidFigura = v;
        Color = c;
     
    }
    void say() {         //Функция, для проверки пустоты ячейки
        if (VidFigura == 0) {     //Если фигура создана конструктором по умолчанию, то клетка пуста
            std::cout << "Пустая клетка\n";
        }
        else
        {
            std::cout << "Figura here\n";
        }
    }
};

class Doska {
   
public:
    void GameOVER(){}     //Конечнаяы
    Figura matrix[8][8];     //Сама доска
    Doska() {     //Конструктор заполняющий доску
    }
    void Zamena(int x, int y, int x2, int y2) {                 //Эта функция заменяет фигуру(кроме пешки)
        if (matrix[x2][y2].Color != matrix[x][y].Color) {
            if (matrix[x2][y2].VidFigura == 4) {     //Если был кароль, то конечная
                GameOVER();
            }
            matrix[x2][y2] = matrix[x][y]; //В новую клетку закидываем фигуру из старой, в старую забиваем фигуру по умолчанию
            matrix[x][y] = Figura();
        }
        else
        {
            std::cout << "Неверный ход\n";
        }
    }   
    void MoveLadya(int x, int y, int x2, int y2) {          //Функция хода ладьи
        if (x == x2 || y == y2) {     //Если Не равна вертикаль и горизонталь, то ладья так не ходит, аривидерчи
            if (x == x2) {     //Если статична вертикаль
                if (y - y2 > 0) {     //То смотрим в какую сторону ходит ладья
                    int j = 0;     //Переменная счетчик
                    for (int i = 1; i < y - y2; i++) {     //Цикл, который пробегает клетки, которые должна пройти фигура
                        if (matrix[x][y - i].VidFigura != 0) {     //Если встречается фигура
                            j++;     //Увиличиваем 
                        }
                    }
                    if (j == 0) {     //Если мы не встретили фигуру, то счетчик будет равен 0, значит ход возможен
                        Zamena(x, x2, y, y2);

                    }
                    else {
                        std::cout << "Неверный ход\n";
                    }

                }
                else {     //Та же операция, только если ладья ходит в другую сторону
                    int j = 0;
                    for (int i = 1; i < y2 - y; i++) {
                        if (matrix[x][y + i].VidFigura != 0) {
                            j++;
                        }
                    }
                    if (j == 0) {
                        Zamena(x, x2, y, y2);
                    }
                    else {
                        std::cout << "Неверный ход\n";
                    }
                }
            }
            else {     //Все то же самое, только если статичная не вертикаль, а горизонталь

                if (x - x2 > 0) {
                    int j = 0;
                    for (int i = 1; i < x - x2; i++) {
                        if (matrix[x - i][y].VidFigura != 0) {
                            j++;
                        }
                    }
                    if (j == 0) {
                        Zamena(x, x2, y, y2);
                    }
                    else {
                        std::cout << "Неверный ход\n";
                    }

                }
                else {
                    int j = 0;
                    for (int i = 1; i < x2 - x; i++) {
                        if (matrix[x + i][y].VidFigura != 0) {
                            j++;
                        }
                    }
                    if (j == 0) {
                        Zamena(x, x2, y, y2);
                    }
                    else {
                        std::cout << "Неверный ход\n";
                    }
                }

            }

        }
        else {
            std::cout << "Неверный ход\n";
        }
    }
    void MoveSlon(int x, int y, int x2, int y2) {           //Функция хода слона
        if (abs(x2 - x) == abs(y2 - y)) {   //Если разность х и у по модулю не одинакова, то слон так не ходит
            if (x - x2 > 0) {     //Узнаем в какую сторону ходит слон
                if (y - y2 > 0) {
                    int j = 0;     //Та же схема, что и с ладьей
                    for (int i = 1; i < y - y2; i++) {

                        if (matrix[x - i][y - i].VidFigura != 0) {
                            j++;
                        }
                    }
                    if (j == 0) {
                        Zamena(x, x2, y, y2);
                    }
                    else {
                        std::cout << "Неверный ход\n";
                    }
                }
                else {     //Если слон идет в другую сторону
                    int j = 0;
                    for (int i = 1; i < y2 - y; i++) {

                        if (matrix[x - i][y + i].VidFigura != 0) {
                            j++;
                        }
                    }
                    if (j == 0) {
                        Zamena(x, x2, y, y2);
                    }
                    else {
                        std::cout << "Неверный ход\n";
                    }
                }
            }
            else {     //Опять же если в другую, все то же самое
                if (y - y2 > 0) {
                    int j = 0;
                    for (int i = 1; i < y - y2; i++) {

                        if (matrix[x + i][y - i].VidFigura != 0) {
                            j++;
                        }
                    }
                    if (j == 0) {
                        Zamena(x, x2, y, y2);
                    }
                    else {
                        std::cout << "Неверный ход\n";
                    }
                }
                else {
                    int j = 0;
                    for (int i = 1; i < y2 - y; i++) {

                        if (matrix[x + i][y + i].VidFigura != 0) {
                            j++;
                        }
                    }
                    if (j == 0) {
                        Zamena(x, x2, y, y2);
                    }
                    else {
                        std::cout << "Неверный ход\n";
                    }
                }
            }

        }
        else
        {
            std::cout << "Неверный ход\n";
        }
    }
    void MovePeshka(int x, int y, int x2, int y2,bool z) {             //Функция хода пешки, если bool z=тру, тогда пешка бьет фигуру, а если фолс, тогда просто ходит
        if (z) {
            if (matrix[x2][y2].VidFigura == 4) {    //Если был кароль, то конечная
                GameOVER();
            }
            matrix[x2][y2] = matrix[x][y]; //В новую клетку закидываем фигуру из старой, в старую забиваем фигуру по умолчанию
            matrix[x][y] = Figura();
        }
        else {
            matrix[x2][y2] = matrix[x][y]; //В новую клетку закидываем фигуру из старой, в старую забиваем фигуру по умолчанию
            matrix[x][y] = Figura();
        }
    }
    void Move(int x, int y, int x2, int y2) {     //Функция хода (х и у - старая клетка, х2 и у2 - клетка новая)
        if (x < 0 || y < 0 || x2 < 0 || y2 < 0 || x > 7 || y > 7 || x2 > 7 || y2 > 7) {     //проверка на выход за пределы доски
            std::cout << "Выход за границы доски\n";     //Если да, то сразу пока
        }
        else {
            if (matrix[x][y].VidFigura == 1) {      //Ладья
                MoveLadya(x, x2, y, y2);
            }
            if (matrix[x][y].VidFigura == 2) { //Конь
                if (
                    (x2==(x-2)&&(y2==y+1|| y2 == y - 1))||     //Если выбранная клетка не соответствует той куда может ходить конь, аривидерчи
                    (x2 == (x - 1) && (y2 == y + 2 || y2 == y - 2))||
                    (x2 == (x + 1) && (y2 == y + 2 || y2 == y - 2))||
                    (x2 == (x + 2) && (y2 == y + 1 || y2 == y - 1))
                    ) {
                    Zamena(x, x2, y, y2);
                    
                }
                else {
                    std::cout << "Неверный ход\n";
                }
            }
            if (matrix[x][y].VidFigura == 3)   //Слон
            {
                MoveSlon(x, x2, y, y2);
            }
            if (matrix[x][y].VidFigura == 4) {   //Король
                if (
                    ((abs(x2 - x) == 1)&&(abs(y2 - y)==1))||   //Если по диагоналям, и по прямым разность не равна 1
                    ((y==y2)&&(abs(x2 - x) == 1))||
                    ((x==x2)&& (abs(y2 - y) == 1))
                    ) {
                    Zamena(x, x2, y, y2);
                }
                else {
                    std::cout << "Неверный ход\n";
                }
            }
            if (matrix[x][y].VidFigura == 5) {   //Ферзь
                if (
                    (x==x2||y==y2)||   //Если ходит иначе, чем слон или ладья, то ошибка
                    (abs(x2 - x) == abs(y2 - y))
                    ) {
                    if (x == x2 || y == y2) {     //Если одна из линий не меняется, то ходит, как ладья, а значит все то же самое
                        MoveLadya(x, x2, y, y2);
                    }
                    else {     //Если же не как ладья, то как слон, копируем код от туда...
                        MoveSlon(x, x2, y, y2);
                    }
                }
                else {
                    std::cout << "Неверный ход\n";
                }
            }
            if (matrix[x][y].VidFigura == 6) {   //Пешка
                if (matrix[x][y].Color==1) {   //Проверка на цвет
                    if (x == 6) {   //Проверка на начальную клетку
                        if ((x2 == (x - 1)) || (x2 == (x - 2))) {   //Если на начальной клетке, то может ходить на две клетки
                            if (x2 == (x - 2)) {     //Если на две, то проверяем две клетки
                                if (matrix[x - 1][y].Color == 2 && matrix[x - 2][y].Color == 2) {
                                    MovePeshka(x, y, y2, x2, false);
                                }
                                else
                                {
                                    std::cout << "Неверный ход\n";
                                }
                            }
                            else {
                                if (matrix[x - 1][y].Color == 2) {     //на одну, то проверяем одну
                                    MovePeshka(x, y, y2, x2, false);
                                }
                                else
                                {
                                    std::cout << "Неверный ход\n";
                                }
                            }
                            if (matrix[x - 1][y + 1].Color == 0 || matrix[x - 1][y - 1].Color == 0) {    //Пешка так же может кушать, если рядом есть фигуры
                                MovePeshka(x, y, y2, x2, true);
                                
                            }
                        }
                        else
                        {
                            std::cout << "Неверный ход\n";
                        }
                    }
                    else   //Если позиция не начальная, то на одну
                    {
                        if (x2 == (x - 1)) {     //Проверка клетки
                            if (matrix[x - 1][y].Color == 2) {
                                MovePeshka(x, y, y2, x2, false);
                            }
                            else
                            {
                                std::cout << "Неверный ход\n";
                            }
                        }
                        else
                        {
                            std::cout << "Неверный ход\n";
                        }
                        if (matrix[x - 1][y + 1].Color == 0 || matrix[x - 1][y - 1].Color == 0) {
                            MovePeshka(x, y, y2, x2, true);
                            
                        }
                    }
                }
                else {
                    if (x == 1) {   //то же самое для черных
                        if ((x2 == (x + 1)) || (x2 == (x + 2))) {
                            if (x2 == (x + 2)) {     //Если нa две
                                if (matrix[x + 1][y].Color == 2 && matrix[x + 2][y].Color == 2) {
                                    MovePeshka(x, y, y2, x2, false);
                                }
                                else
                                {
                                    std::cout << "Неверный ход\n";
                                }
                            }
                            else {      // Если нa одну
                                if (matrix[x + 1][y].Color == 2) {
                                    MovePeshka(x, y, y2, x2, false);
                                }
                                else
                                {
                                    std::cout << "Неверный ход\n";
                                }
                            }
                            if (matrix[x + 1][y + 1].Color == 1 || matrix[x + 1][y - 1].Color == 1) {
                                MovePeshka(x, y, y2, x2, true);
                                
                            }
                        }
                        else
                        {
                            std::cout << "Неверный ход\n";
                        }
                    }
                    else
                    {
                        if (x2 == (x + 1)) {     //Если на одну
                            if (matrix[x + 1][y].Color == 2) {
                                MovePeshka(x, y, y2, x2, false);
                            }
                            else
                            {
                                std::cout << "Неверный ход\n";
                            }
                        }
                        else
                        {
                            std::cout << "Неверный ход\n";
                        }
                        if (matrix[x + 1][y + 1].Color == 1 || matrix[x + 1][y - 1].Color == 1) {
                            MovePeshka(x, y, y2, x2, true);
                            
                        }
                    }
                }

            }
        }
        
    }
    void Cleaner(Doska& d) {     //Функция расстановки фигур
        d.matrix[0][0] = Figura(1, false);      //Заполнение черных фигур
        d.matrix[0][7] = Figura(1, false);
        d.matrix[0][1] = Figura(2, false);
        d.matrix[0][6] = Figura(2, false);
        d.matrix[0][2] = Figura(3, false);
        d.matrix[0][5] = Figura(3, false);
        d.matrix[0][3] = Figura(5, false);
        d.matrix[0][4] = Figura(4, false);
        for (int i = 0; i < 8;i++) {
            d.matrix[1][i] = Figura(6, false);
        }
        d.matrix[7][0] = Figura(1, true);     //Белых
        d.matrix[7][7] = Figura(1, true);
        d.matrix[7][1] = Figura(2, true);
        d.matrix[7][6] = Figura(2, true);
        d.matrix[7][2] = Figura(3, true);
        d.matrix[7][5] = Figura(3, true);
        d.matrix[7][3] = Figura(5, true);
        d.matrix[7][4] = Figura(4, true);
        for (int i = 0; i < 8; i++) {
            d.matrix[6][i] = Figura(6, true);
        }
        for (int i = 2; i < 6; i++) {     //Пустые
            for (int j = 0; j < 8; j++) {
                d.matrix[i][j] = Figura();
            }
        }
    }
};


int main()
{
    setlocale(LC_ALL, "Russian");
    Doska MyDoska = Doska();     //Проверка...
    MyDoska.matrix[4][3].say();
    MyDoska.matrix[2][4].say();
    MyDoska.Move(4, 3, 2, 4);
    MyDoska.matrix[4][3].say();
    MyDoska.matrix[2][4].say();

}

